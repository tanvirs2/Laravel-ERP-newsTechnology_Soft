<tbody id="childTable">
<?php $var = 1; $orderQtySum = 0; $orderTotalValue = 0; $totShipQty = 0; $totShipVal = 0; $totShrtShipVal = 0; $totSMV=0; ?>
{{--*/ $prCut=0; $prSwIn=0; $prSwOut=0; $prIron=0; $prCarton=0; $prCmSum=0; $prSwInVal=0; /*--}}
@foreach ($employees as $employee)
    <tr class="orderRow" id="row" orderId="" style="">
        <td class="text-center">
            {{ $var++ }}
            <small class="text-aqua">{{ $employee->Id }}</small>
        </td>

        <td class="text-center blackCol">
            {{ $employee['customer_name'] }}
        </td>
        <td style="overflow: auto;" class="text-center">
            {{ $employee['orderID'] }}
        </td>
        <td class="text-center">
            {{ $employee['article_no'] }}
        </td>
        <td class="text-center">
            {{ $employee['style_description'] }}
        </td>
        <td class="text-center">
            <img class="imgPreview" src="{{ asset('') }}assets/garmentsImage/{{ $employee['garmentImg'] }}" alt="" height="50" width="50"/>
        </td>
        <td class="text-center btn btn-default">
            <?php
            $date_of_ship = $employee['date_of_ship'];
            $date_of_ship = DateTime::createFromFormat('Y-m-d', $date_of_ship);
            $date_of_ship = $date_of_ship->format('d-m-Y');
            echo $date_of_ship;
            ?>
        </td>
        <td class="text-center" id="">
            <span class="shpDays">
                <?php
                $order_status = $employee['order_status'];
                $actualShipDate = $employee['actualShipDate'];
                if ($order_status == 'ShipOut') {
                    //Remaining Days for Shipment Date
                    $dateStr=$employee['date_of_ship'];
                    $date=strtotime($dateStr);//Converted to a PHP date (a second count)
                    //Calculate difference
                    $diff=$date-strtotime($actualShipDate);//time returns current time in seconds
                    $days=floor($diff/(60*60*24));//seconds/minute*minutes/hour*hours/day)
                    $hours=round(($diff-$days*60*60*24)/(60*60));
                    //Report
                    echo $days;
                } else {
                    //Remaining Days for Shipment Date
                    $dateStr=$employee['date_of_ship'];
                    $date=strtotime($dateStr);//Converted to a PHP date (a second count)
                    //Calculate difference
                    $diff=$date-time();//time returns current time in seconds
                    $days=floor($diff/(60*60*24));//seconds/minute*minutes/hour*hours/day)
                    $hours=round(($diff-$days*60*60*24)/(60*60));
                    //Report
                    echo $days+1;
                }
                ?>
            </span>
            <span>Days</span>
        </td>
        <td class="text-center">
            {{ $employee['order_quantity']}}
            <?php $orderQtySum += $employee['order_quantity']?>
        </td>


        <td class="text-center">
            @if(isset($employee['date']))
                {{ $employee['date'] }}
            @endif
        </td>

        <td class="text-center blackCol">
            @if(isset($employee['cut']))
                {{ $employee['cut']}}
                {{--*/$prCut += $employee['cut'] /*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['line']))
                {{ $employee['line']}}
            @endif

        </td>
        <td class="text-center blackCol">
            @if(isset($employee['swingIn']))
                {{ $employee['swingIn']}}
                {{--*/$prSwIn += $employee['swingIn']/*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['swingOut']))
                {{ $employee['swingOut']}}
                {{--*/$prSwOut += $employee['swingOut']/*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['swingOut']))
                {{ $employee['swingOut']*$employee['unit_price']}}
                {{--*/ $prSwInVal += $employee['swingOut']*$employee['unit_price']/*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['swingOut']))
                {{ round(($employee['cmPerDz']*$employee['swingOut'])/12) }}
                {{--*/ $prCm = ($employee['cmPerDz']*$employee['swingOut'])/12 /*--}}
                {{--*/ $prCmSum += $prCm /*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['swingOut']))
                {{ $employee['smv']* $employee['swingOut']}}
                {{--*/ $totSMV += $employee['smv']/*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['iron']))
                {{ $employee['iron']}}
                {{--*/$prIron += $employee['iron'] /*--}}
            @endif
        </td>
        <td class="text-center blackCol">
            @if(isset($employee['carton']))
                {{ $employee['carton']}}
                {{--*/$prCarton += $employee['carton']/*--}}
            @endif
        </td>

    </tr>
@endforeach
</tbody>
<tfoot>
<tr style="color: #233446; background: #a5b6b7; text-shadow: 0 0 4px #fffdfe">
    <td></td>

    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td><b>TotOrdQty</b></td>

    <td><b></b></td>
    <td><b>TotCut</b></td>
    <td><b></b></td>
    <td><b>TotSwIn</b></td>
    <td><b>TotSwOut</b></td>
    <td><b>Value</b></td>
    <td><b>CM</b></td>
    <td><b>SMV</b></td>
    <td><b>TotIron</b></td>
    <td><b>TotPoly</b></td>
    <td></td>
</tr>
<tr style="background-color: #34495e; color: whitesmoke; font-weight: bolder; font-size: 1.3em">
    <td></td>

    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td><b>{{ $orderQtySum }}</b></td>

    <td><b></b></td>
    <td><b>{{ $prCut }}</b></td>
    <td><b></b></td>
    <td><b>{{ $prSwIn }}</b></td>
    <td><b>{{ $prSwOut }}</b></td>
    <td><b>{{ $prSwInVal }}</b></td>
    <td><b>{{ round($prCmSum) }}</b></td>
    <td><b>{{ $totSMV }}</b></td>
    <td><b>{{ $prIron }}</b></td>
    <td><b>{{ $prCarton }}</b></td>
    <td></td>
</tr>
</tfoot>

<script>
    $( ".shpDays" ).each(function(){
        var value = parseInt( $( this ).html() );
        if ( value <= 10 )
        {
            $( this ).parent().css('background-color', '#ff9900');
        }
        if ( value == 0 )
        {
            $(this).parent().attr('class', 'animated infinite pulse').css({"background-color": "#cc0000", "color": "#ffffff"});
        }
        if ( value < 0 )
        {
            $( this ).parent().css('background-color', 'red');
        }
    });
    $(".shpDays").closest('tr').find('.shipmntSts').each(function () {
        var value = $( this ).text().trim();
        if (value == "ShipOut") {
            $(this).closest('tr').find('.shpDays').parent().css({'color':'white', 'background-color' : '#8e44ad'});
        }
    });
</script>
